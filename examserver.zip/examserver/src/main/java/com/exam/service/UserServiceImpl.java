package com.exam.service;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exam.entity.User;
import com.exam.entity.UserRole;
import com.exam.repository.RoleRepository;
import com.exam.repository.UserRepository;

import jakarta.transaction.Transactional;


@Service
@Transactional
public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserRepository userRepository;
	
	
	@Autowired
	private RoleRepository roleRepository;
	
	
   // creating user
	@Override
	public User createUser(User user, Set<UserRole> userRoles) throws Exception {
		// TODO Auto-generated method stub
		
		User local= this.userRepository.findByUserName(user.getUsername());
		
		if(local!=null) {
			System.out.println("User is already there !!");
			throw new Exception("User already present!!");
		}
		else {
			//user create karo
			for(UserRole ur: userRoles) {
				this.roleRepository.save(ur.getRole());  //saving given roles to roles entity(or to database) through rolerepository
				
			}
			
			user.getUserRoles().addAll(userRoles); //assign given user to given roles
			local=this.userRepository.save(user);
		}
		return local;
	}

}
