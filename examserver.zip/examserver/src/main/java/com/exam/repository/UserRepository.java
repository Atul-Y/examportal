package com.exam.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.exam.entity.User;

@Repository
public interface UserRepository  extends CrudRepository<User, Long>{

	public User findByUserName(String username);
	
	

}
