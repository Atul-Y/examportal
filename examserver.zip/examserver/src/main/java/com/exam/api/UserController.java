package com.exam.api;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.exam.entity.Role;
import com.exam.entity.User;
import com.exam.entity.UserRole;
import com.exam.service.UserService;

@RestController
@RequestMapping("/user")
@CrossOrigin("*")
public class UserController {
	
	@Autowired
	private UserService userService;
	
	//creating user

   @PostMapping("/abc")
   public User createUser(@RequestBody User user) throws Exception {
	   
	   Set<UserRole> roles=new HashSet<>();
	   
	   Role role = new Role();
	   role.setRoleId(45L);
	   role.setRoleName("NORMAL");
	   
	   UserRole  userRole= new UserRole();
	   userRole.setRole(role);   //ye jo role abhi hamne uper banaya tha 
	   userRole.setUser(user);
	   
	  roles.add(userRole);
	return this.userService.createUser(user, roles);
	   
   }

}
 